/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wetterwerte;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.ListIterator;
import javax.swing.JOptionPane;

/**
 *
 * @author maxth
 */
public class FileClass {
    
    public static String COMMA_DELIMITER=",";
    public static String LINE_SEPERATOR="\r\n";
    public static String FILE_HEADER="datum, zeit, temperatur, luftfeuchtigkeit";
    
    public static void writeWetterWerte(File file,  ListIterator<Wetterwert> lwwobj){
         FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            fw.append(FILE_HEADER);
            fw.append(LINE_SEPERATOR);
            while(lwwobj.hasNext()) {
                Wetterwert ww = lwwobj.next();
                fw.append(ww.getDatum());
                fw.append(COMMA_DELIMITER);
                fw.append(ww.getZeitpunkt());
                fw.append(LINE_SEPERATOR);
                fw.append(""+ww.getTemperatur());
                fw.append(COMMA_DELIMITER);
                fw.append(""+ww.getLuftfeuchtigkeit());
                fw.append(COMMA_DELIMITER);
            }
        } catch (Exception e) {
            System.out.println("Fehler beim schreiben/speichern der CSV-Datei!");
            e.printStackTrace();
        } finally {
            try {
                fw.flush();
                fw.close();
            } catch (IOException e) {
                System.out.println("Fehler beim flushen oder schließen der CSV-Datei!");
                e.printStackTrace();
            }
        }        
        
    }
    
    
    public static LinkedList<Wetterwert> readWetterWerte(File file) {
        BufferedReader buffi = null;
        FileReader fr = null;
        LinkedList<Wetterwert> end = new LinkedList<Wetterwert>();
        try {
            fr = new FileReader(file);
            buffi = new BufferedReader(fr);
            buffi.readLine();
            String line;
            while ((line = buffi.readLine()) != null) {
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    end.add(new Wetterwert(
                        Integer.parseInt(tokens[0].trim()),
                        Integer.parseInt(tokens[1].trim()),
                        Date.valueOf(tokens[2].trim()),
                        LocalTime.parse(tokens[3].trim())));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Datei nicht gefunden!");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Fehler beim lesen der Datei!");
            e.printStackTrace();
        } finally {
            try {
                if (buffi != null) {
                    buffi.close();
                }
            }catch (IOException e) {
                System.out.println("Fehlerbeim schließenne des Readers!");
                e.printStackTrace();
            }
        }   
        return end;
    }
}
