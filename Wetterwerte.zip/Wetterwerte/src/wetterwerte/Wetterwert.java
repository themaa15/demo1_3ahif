/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wetterwerte;

import java.time.LocalTime;
import java.util.Date;
/**
 *
 * @author maxth
 */
public class Wetterwert {
    
    private int temperatur;
    private int luftfeuchtigkeit;
    private Date datum;
    private LocalTime zeitpunkt;

    public Wetterwert(int temperatur, int luftfeuchtigkeit, Date datum, LocalTime zeitpunkt) {
        this.temperatur = temperatur;
        this.luftfeuchtigkeit = luftfeuchtigkeit;
        this.datum = datum;
        this.zeitpunkt = zeitpunkt;
    }

    Wetterwert(int temperatur, int luftfeuchtigkeit) {
       this.temperatur = temperatur;
       this.luftfeuchtigkeit = luftfeuchtigkeit;
    }

    public int getTemperatur() {
        return temperatur;
    }

    public void setTemperatur(int temperatur) {
        this.temperatur = temperatur;
    }

    public int getLuftfeuchtigkeit() {
        return luftfeuchtigkeit;
    }

    public void setLuftfeuchtigkeit(int luftfeuchtigkeit) {
        this.luftfeuchtigkeit = luftfeuchtigkeit;
    }

    public void setZeitpunkt(LocalTime zeitpunkt) {
        this.zeitpunkt = zeitpunkt;
    }
    
    public String getDatum(){ 
        Date datumjetzt = new Date();
        return datumjetzt.toString();
    }
    
    public String getZeitpunkt(){
        return LocalTime.now().getHour()+":"+LocalTime.now().getMinute()+":"+LocalTime.now().getSecond();
    }
    
    public String toString() {
        return getDatum()+" - "+getZeitpunkt()+" - "+temperatur+ "° - "+luftfeuchtigkeit+"%";
    } 
}
