/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wetterwerte;

import java.util.LinkedList;
import java.util.ListIterator;
import javax.swing.AbstractListModel;

/**
 *
 * @author maxth
 */
public class WetterModell<T> extends AbstractListModel<T> {
    
    private LinkedList<T> lliste;
    
    public WetterModell(){
        this.lliste = new LinkedList<>();
    }
    
    @Override
    public int getSize() {
        return lliste.size();
    }

    @Override
    public T getElementAt(int i) {
        return lliste.get(i);
    }
    
    public void addElement(T wert){
        lliste.add(wert);
    }
    
    public ListIterator<T> getElements(){
        return lliste.listIterator(0);
    }

    void clear() {
        lliste.clear();
    }
}
